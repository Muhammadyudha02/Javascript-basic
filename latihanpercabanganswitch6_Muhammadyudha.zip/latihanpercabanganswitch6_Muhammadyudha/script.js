

console.log("Program kalkulator sederhana")
console.log("1.Penjumlahan")
console.log("2.pengurangan")
console.log("3.perkalian")
console.log("4.Pembagian")
console.log("5.Keluar program")
console.log("")

const menu = prompt("Menu kalkulator(angka) :");
if(menu <=4){
     angka1=parseInt (prompt("angka pertama :"));
     angka2=parseInt (Prompt("angka kedua :"));
     console.log("Angka pertama :"+ angka1)
    console.log("Angka kedua : "+ angka2)  
}

let kalkulator;
switch (menu) {
  case "1":
    kalkulator = (angka1+angka2)
    console.log("Hasil dari: "+angka1+"+"+angka2+"="+kalkulator)
    break;
  case "2":
    kalkulator =(angka1-angka2)
    console.log("Hasil dari: "+angka1+"-"+angka2+"="+kalkulator)
    break;
  case "3":
    kalkulator = (angka1*angka2)
    console.log("Hasil dari: "+angka1+"x"+angka2+"="+kalkulator)
    break;
  case "4":
    kalkulator = (angka1/angka2)
    console.log("Hasil dari: "+angka1+":"+angka2+"="+kalkulator)
    break;
    case"5":
    pesan ="Keluar program"
    console.log("Keluar program...terima kasih!");
    break;
}
