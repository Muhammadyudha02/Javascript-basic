// Volume Balok
// V = p*l*t

let p = 10;
let l = 8;
let t = 5;

const balok = p * l * t;
console.log("Volume Balok" + " " + balok);

// Volume kubus
// V = s*s*s

s = 10;

const kubus = s * s * s;
console.log("Volume Kubus" + " " + kubus);

// Volume Tabung
// V = Π*r*r*t

Π = 2.1;
r = 5;
t = 10;

const tabung = Π * r * r * t;
console.log("Volume Tabung" + " " + tabung);

// Volume Kerucut
// V = 1/3*Π*r*r*t

Π = 4.2;
r = 5;
t = 20;

const kerucut = (1 / 3) * Π * r * r * t;
console.log("Volume Kerucut" + " " + kerucut);

// Volume Bola
// V = 4/3*Π*r*r*r

Π = 3.15;
r = 15;

const Bola = (4 / 3) * Π * r * r * r;
console.log("Volume Bola" + " " + Bola);
