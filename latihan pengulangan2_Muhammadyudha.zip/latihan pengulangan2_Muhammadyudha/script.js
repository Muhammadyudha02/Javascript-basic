const nilai=prompt("Masukan Nilai N:")
let total=0
for (let i=1; i <=nilai; i++){
    total=total+i
}
console.log("Jumlah deret angka")
console.log("Antara 1 sampai "+nilai+" adalah "+total)