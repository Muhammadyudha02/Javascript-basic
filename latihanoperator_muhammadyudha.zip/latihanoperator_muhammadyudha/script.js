//Segitiga
let alassegitiga = 5;
let tinggisegitiga =8;

const luassegitiga=alassegitiga*tinggisegitiga

console.log("luas segitiga :",luassegitiga);
//persegi panjang
let sisia=15;
let sisib=20;

luaspersegipanjang=sisia*sisia
console.log("luas persegi panjang :",luaspersegipanjang)
//lingkaran
let J=10.5;
let L=4.5;

luaslingkaran=J*L
console.log("Luas lingkaran nya adalah :",luaslingkaran)
//belahketupat
let diaginal1=11.5
let diagonal2=15.0

luasbelahketupat=diaginal1*diagonal2
console.log("Luas belah ketupat adalah :",luasbelahketupat)
//trapesium
let alasc=15
let alasd=20
let tinggi=5

luastrapesium=1/2+(alasc+alasd)*tinggi
console.log("luas trapesium",luastrapesium)