//Latihan 1
/*
for(let i=1; i<=50; i++){
    if(i%2==0)
    {
    console.log(i+" Adalah bilangan genap");}
    else{
    console.log(i+" Adalah bilangan ganjil");}
}
*/
//latihan 2
/*
for(let i=1; i<=100; i++){
    if(i%3==0)
    {
    console.log(i+" Adalah Bilangan yang habis dibagi 3");
}
    else{
    console.log(i)}
}
*/

//latihan 3
let i=50;
while (i<=150){
if(i%4==0)
{console.log(i+" Bilangan yang habis di bagi 4 ");}

else{
    console.log(i)
}
i++;
}