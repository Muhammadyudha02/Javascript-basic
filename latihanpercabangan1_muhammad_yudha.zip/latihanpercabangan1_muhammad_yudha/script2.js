const nilai1 =prompt("Masukan nilai anda: ")
if (nilai1>=85 && nilai1<=100){console.log("Nilai anda adalah A")}
 else if (nilai1>=75 && nilai1<=85){console.log("Nilai anda adalah B")}
 else if (nilai1>=65 && nilai1<=75) {console.log("Nilai anda adalah C")}
 else if (nilai1>=55 && nilai1<=65) {console.log("Nilai anda adalah D")}
 else if (nilai <=50){console.log("Nilai anda adalah E")}

