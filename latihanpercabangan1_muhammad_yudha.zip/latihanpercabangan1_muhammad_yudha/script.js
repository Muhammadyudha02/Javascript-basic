const nilai =prompt("Masukan nilai anda: ")

if (nilai>=75){console.log("Anda lulus mata kuliah ini")}
 else if (nilai<=75){console.log("Anda belum lulus mata kuliah ini,silahkan mengulang!")}
 else{console.log("")}